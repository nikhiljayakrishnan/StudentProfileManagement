﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentService.DBContexts;
using StudentService.Dtos;
using StudentService.Entities;

namespace StudentService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly MyDBContext _context;
        public StudentController(MyDBContext context)
        {
            _context = context;
        }
        // GET: api/Students
        [HttpGet("GetStudents")]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudents()
        {
            if (_context.Students == null)
            {
                return NotFound();
            }
            return Ok(await _context.Students.ToListAsync());
            ///needs to show the Student and students count
        }

        // GET: api/Students/5
        [HttpGet("GetStudent/{id}")]
        public async Task<ActionResult<Student>> GetStudent(int id)
        {
            if (_context.Students == null)
            {
                return NotFound();
            }
            var Student = await _context.Students.FindAsync(id);

            if (Student == null)
            {
                return NotFound();
            }

            return Student;
        }

        // PUT: api/Students/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("UpdateStudent")]
        public async Task<IActionResult> UpdateStudent(StudentDto student)
        {
            if (student.Id == 0)
            {
                return BadRequest();
            }
            var studentEntity = await _context.Students.FindAsync(student.Id);

            if (student.Name != "string")
            {
                studentEntity.Name = student.Name;
            }
            if (student.DepartmentId != 0)
            {
                studentEntity.DepartmentId = student.DepartmentId;

            }
            if (student.StaffId != 0)
            {
                student.StaffId = student.StaffId;

            }
            _context.Students.Update(studentEntity);


            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentExists(student.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Students
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("CreateStudent")]
        public async Task<ActionResult<Student>> Create([FromBody] CreateStudentDto student)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var studentEntity = new Student()
            {
                Name = student.Name,
                DepartmentId = student.DepartmentId,
                StaffId = student.StaffId,
                EmailAddress = student.EmailAddress,
                Password = student.Password
            };
            await _context.Students.AddAsync(studentEntity);
            await _context.SaveChangesAsync();

            return Ok(studentEntity);
        }

        // DELETE: api/Students/5
        [HttpDelete("DeleteStudent/{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            if (_context.Students == null)
            {
                return NotFound();
            }
            var Student = await _context.Students.FindAsync(id);
            if (Student == null)
            {
                return NotFound();
            }

            _context.Students.Remove(Student);
            await _context.SaveChangesAsync();

            return Ok();
        }
        [HttpGet("GetStudentsByDepartmentId/{departmentId}")]
        public async Task<List<Student>> GetStudentsByDepartmentId(int departmentId)
        {
            if (_context.Students == null)
            {
                return new List<Student>();
            }
            var students = await _context.Students.Where(s => s.DepartmentId == departmentId).ToListAsync();
            return students;
        }
        [HttpGet("GetStudentsByStaffId/{staffId}")]
        public async Task<List<Student>> GetStudentsByStaffId(int staffId)
        {
            if (_context.Students == null)
            {
                return new List<Student>();
            }
            var students = await _context.Students.Where(s => s.StaffId == staffId).ToListAsync();
            return students;
        }
        private bool StudentExists(int id)
        {
            return (_context.Students?.Any(e => e.Id == id)).GetValueOrDefault();
        }
        [HttpGet("ApproveStudentRegistration/{studentId}")]
        public async Task<ActionResult<Student>> ApproveStudentRegistration(int studentId)
        {
            if (_context.Students == null)
            {
                return NotFound();
            }
            var student = await _context.Students.FirstOrDefaultAsync(s => s.Id == studentId);
            if (student != null)
            {
                student.IsStaffVerified = true;
                _context.Students.Update(student);
                await _context.SaveChangesAsync();
                return Ok(student);
            }
            else
                return NotFound();

        }
        [HttpGet("GetStudentByCredentials")]
        public async Task<ActionResult<Student>> GetStudentByCredentials(string emailAddress, string password)
        {
            if (string.IsNullOrEmpty(emailAddress) || string.IsNullOrEmpty(password))
            {
                return BadRequest("EmailAddress and password are required.");
            }

            var student = await _context.Students.FirstOrDefaultAsync(s => s.EmailAddress == emailAddress && s.Password == password);

            if (student == null)
            {
                return NotFound("Staff not found.");
            }

            return student;
        }
    }
}
