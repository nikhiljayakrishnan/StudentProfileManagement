﻿
using Microsoft.EntityFrameworkCore;
using StudentService.Entities;

namespace StudentService.DBContexts
{
    public class MyDBContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public MyDBContext(DbContextOptions<MyDBContext> options) : base(options)
        {

        }
    }
}
