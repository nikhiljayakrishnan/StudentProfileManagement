﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace StudentService.Entities
{
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }
        public int DepartmentId { get; set; }
        public int StaffId { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public bool IsStaffVerified { get; set; }

    }
}
