﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace StudentManagement.Model
{
    public class AdminCredentials
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }

    }
    public class AdminCredentialData
    {
        public List<AdminCredentials> AdminCredentials { get; set; } = new List<AdminCredentials>
    {
        new AdminCredentials
        {
            Id = 1,
            Name = "Admin",
            EmailAddress = "admin123@yopmail.com",
            Password = "123qwe"
        },
        
    };

       
    }


}
