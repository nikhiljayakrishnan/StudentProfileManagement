﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentManagement.Model
{
    public class StaffDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public TypeEnum Type { get; set; }
        public int? DepartmentId { get; set; }
        public string Category { get; set; }

    }
    public enum TypeEnum
    {
        [Display(Name = "None")]
        None = 0,
        [Display(Name = "Teacher")]
        Teacher = 1,
        [Display(Name = "NonTeaching Staff")]
        NonTeachingStaff = 2
    }
}
