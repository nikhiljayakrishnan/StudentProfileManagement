﻿

namespace StudentManagement.Model
{
    public class CreateStaffDto
    {
        public string Name { get; set; }
        public TypeEnum Type { get; set; }
        public int? DepartmentId { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
