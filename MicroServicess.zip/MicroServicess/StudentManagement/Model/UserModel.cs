﻿namespace StudentManagement.Model
{
    public class UserModel
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }

}
