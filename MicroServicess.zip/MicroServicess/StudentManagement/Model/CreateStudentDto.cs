﻿namespace StudentManagement.Model
{
    public class CreateStudentDto
    {
        public string Name { get; set; }
        public int DepartmentId { get; set; }
        public int StaffId { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
