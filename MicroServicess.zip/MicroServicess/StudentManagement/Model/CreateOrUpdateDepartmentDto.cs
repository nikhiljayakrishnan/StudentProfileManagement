﻿namespace StudentManagement.Model
{
    public class CreateOrUpdateDepartmentDto
    {
        public string Name { get; set; }
        public string? Subject { get; set; }
    }
}
