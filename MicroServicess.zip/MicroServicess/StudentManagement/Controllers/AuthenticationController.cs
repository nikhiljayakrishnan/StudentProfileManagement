﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using StudentManagement.Model;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthenticationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public AuthenticationController(IConfiguration configuration)
        {
            _configuration = configuration;
          
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
            })
            .ToArray();
        }
        [HttpPost("GetAdminByCredentials")]
        public async Task<ActionResult<AdminCredentials>> GetAdminByCredentials([FromBody] UserModel user)
        {
           
            // Check your user authentication logic here (compare user.Username and user.Password)

            if (string.IsNullOrEmpty(user.EmailAddress) || string.IsNullOrEmpty(user.Password))
            {
                return BadRequest("EmailAddress and password are required.");
            }
            AdminCredentialData credentials = new AdminCredentialData();
            var admin = credentials.AdminCredentials.FirstOrDefault(s => s.EmailAddress == user.EmailAddress && s.Password == user.Password);

            if (admin == null)
            {
                return NotFound(" Not found.");
            }

            return admin;
        }
       
        [HttpPost("GenerateJwtToken")]
        public object GenerateJwtToken(UserModel user)
        {
            var key = Encoding.UTF8.GetBytes(_configuration["Jwt:Secret"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.Name, user.EmailAddress)
                }),
                Expires = DateTime.UtcNow.AddHours(1), // Token expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenvalue=tokenHandler.WriteToken(token);
            return new { token = tokenvalue };

        }
    }
}
