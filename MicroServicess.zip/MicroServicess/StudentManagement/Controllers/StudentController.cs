﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentManagement.Model;
using System.Net;
using System.Text;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {

        public string studentUrl = "http://localhost:39384/";
        private readonly HttpClient _httpClient;
        public StudentController(HttpClient httpClient)
        {

            _httpClient = httpClient;

        }
        [HttpGet("GetStudents")]
        public async Task<ActionResult<IEnumerable<StudentDto>>> GetStudents()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(studentUrl + "api/Student/GetStudents"); // Adjust URL as needed
            List<StudentDto> Students = new List<StudentDto>();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    Students = await response.Content.ReadFromJsonAsync<List<StudentDto>>();

                }

            }
            return Ok(Students);
        }
        // GET: api/Student/5
        [HttpGet("GetStudent/{id}")]
        public async Task<ActionResult<StudentDto>> GetStudent(int id)
        {
            HttpResponseMessage response = await _httpClient.GetAsync(studentUrl + "api/Student/GetStudent/" + id); // Adjust URL as needed
            StudentDto Student = new StudentDto();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    Student = await response.Content.ReadFromJsonAsync<StudentDto>();

                }

            }
            return Ok(Student);
        }
        public async Task<IActionResult> UpdateStudent(StudentDto Student)
        {
            if (Student.Id == 0)
            {
                return BadRequest();
            }

            // Assuming you have the base URL stored in studentUrl
            string updatestudentUrl = $"{studentUrl}api/Student/UpdateStudent";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(Student);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PutAsync(updatestudentUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            else
            {
                // Handle other status codes as needed
                return StatusCode((int)response.StatusCode);
            }
        }
        [HttpPost("CreateStudent")]
        public async Task<ActionResult<DepartmentDto>> Create([FromBody] CreateStudentDto createStudentDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Assuming you have the base URL stored in studentUrl
            string updatestudentUrl = $"{studentUrl}api/Student/CreateStudent";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(createStudentDto);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PostAsync(updatestudentUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            else
            {
                // Handle other status codes as needed
                return StatusCode((int)response.StatusCode);
            }
        }

        // DELETE: api/Student/5
        [HttpDelete("DeleteStudent/{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Assuming you have the base URL stored in studentUrl
            string updatestudentUrl = $"{studentUrl}api/Student/DeleteStudent";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(id);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PostAsync(updatestudentUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            else
            {
                // Handle other status codes as needed
                return StatusCode((int)response.StatusCode);
            }
        }

        [HttpPost("GetStudentByCredentials")]
        public async Task<ActionResult<StaffDto>> GetStudentByCredentials(UserModel user)
        {
            if (string.IsNullOrEmpty(user.EmailAddress) || string.IsNullOrEmpty(user.Password))
            {
                return BadRequest("EmailAddress and password are required.");
            }
            // Assuming you have the base URL stored in staffUrl
            string getStudentByCredentialUrls = $"{studentUrl}api/GetStudentByCredentials?emailAddress={user.EmailAddress}&password={user.Password}";

            // Send the HTTP GET request
            HttpResponseMessage response = await _httpClient.GetAsync(getStudentByCredentialUrls);

            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    var staff = await response.Content.ReadFromJsonAsync<StaffDto>();
                    return Ok(staff);
                }
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound("Student not found.");
            }

            // Handle other status codes as needed
            return StatusCode((int)response.StatusCode);
        }

        [HttpGet("ApproveStudentRegistration/{studentId}")]
        public async Task<ActionResult<StudentDto>> ApproveStudentRegistration(int studentId)
        {
            HttpResponseMessage response = await _httpClient.GetAsync(studentUrl + "api/Student/ApproveStudentRegistration/" + studentId); // Adjust URL as needed
            StudentDto Student = new StudentDto();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    Student = await response.Content.ReadFromJsonAsync<StudentDto>();

                }

            }
            return Ok(Student);
        }
    }
}
