﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentManagement.Model;
using System.Net;
using System.Text;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DepartmentController : ControllerBase
    {
        public string departmentUrl = "http://localhost:39965/";
        private readonly HttpClient _httpClient;
        public DepartmentController(HttpClient httpClient)
        {

            _httpClient = httpClient;

        }
        [HttpGet("GetDepartments")]
        public async Task<ActionResult<IEnumerable<DepartmentDto>>> GetDepartments()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(departmentUrl+ "api/Departments/GetDepartments"); // Adjust URL as needed
            List<DepartmentDto> departments = new List<DepartmentDto>();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    departments = await response.Content.ReadFromJsonAsync<List<DepartmentDto>>();

                }

            }
            return Ok(departments);
        }
        // GET: api/Departments/5
        [HttpGet("GetDepartment/{id}")]
        public async Task<ActionResult<DepartmentDto>> GetDepartment(int id)
        {
            HttpResponseMessage response = await _httpClient.GetAsync(departmentUrl + "api/Departments/GetDepartment/"+id); // Adjust URL as needed
            DepartmentDto department = new DepartmentDto();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    department = await response.Content.ReadFromJsonAsync<DepartmentDto>();

                }

            }
            return Ok(department);
        }
        [HttpPut("UpdateDepartment")]
        public async Task<IActionResult> UpdateDepartment(DepartmentDto department)
        {
            if (department.Id == 0)
            {
                return BadRequest();
            }

            // Assuming you have the base URL stored in departmentUrl
            string updateDepartmentUrl = $"{departmentUrl}api/Departments/UpdateDepartment";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(department);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PutAsync(updateDepartmentUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            return NoContent();


        }
        [HttpPost("CreateDepartment")]
        public async Task<ActionResult<DepartmentDto>> Create([FromBody] CreateOrUpdateDepartmentDto createOrUpdateDepartmentDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Assuming you have the base URL stored in departmentUrl
            string updateDepartmentUrl = $"{departmentUrl}api/Departments/CreateDepartment";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(createOrUpdateDepartmentDto);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PostAsync(updateDepartmentUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
                return NoContent();

        }

        // DELETE: api/Departments/5
        [HttpDelete("DeleteDepartment/{id}")]
        public async Task<IActionResult> DeleteDepartment(int id)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Assuming you have the base URL stored in departmentUrl
            string updateDepartmentUrl = $"{departmentUrl}api/Departments/DeleteDepartment/"+id;

           
            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.DeleteAsync(updateDepartmentUrl);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);

            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            return NoContent();

        }


    }
}
