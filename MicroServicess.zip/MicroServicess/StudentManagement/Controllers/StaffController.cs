﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentManagement.Model;
using System.Net;
using System.Text;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StaffController : ControllerBase
    {
        public string staffUrl = "http://localhost:21750/";
        private readonly HttpClient _httpClient;
        public StaffController(HttpClient httpClient)
        {

            _httpClient = httpClient;

        }
        [HttpGet("GetStaffs")]
        public async Task<ActionResult<IEnumerable<StaffDto>>> GetStaffs()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(staffUrl + "api/Staff/GetStaffs"); // Adjust URL as needed
            List<StaffDto> staffs = new List<StaffDto>();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    staffs = await response.Content.ReadFromJsonAsync<List<StaffDto>>();

                }

            }
            return Ok(staffs);
        }
        // GET: api/Staff/5
        [HttpGet("GetStaff/{id}")]
        public async Task<ActionResult<StaffDto>> GetStaff(int id)
        {
            HttpResponseMessage response = await _httpClient.GetAsync(staffUrl + "api/Staff/GetStaff/" + id); // Adjust URL as needed
            StaffDto staff = new StaffDto();
            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    staff = await response.Content.ReadFromJsonAsync<StaffDto>();

                }

            }
            return Ok(staff);
        }
        public async Task<IActionResult> UpdateStaff(StaffDto staff)
        {
            if (staff.Id == 0)
            {
                return BadRequest();
            }

            // Assuming you have the base URL stored in staffUrl
            string updatestaffUrl = $"{staffUrl}api/Staff/UpdateStaff";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(staff);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PutAsync(updatestaffUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            else
            {
                // Handle other status codes as needed
                return StatusCode((int)response.StatusCode);
            }
        }
        [HttpPost("CreateStaff")]
        public async Task<ActionResult<StaffDto>> Create([FromBody] CreateStaffDto createStaffDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Assuming you have the base URL stored in staffUrl
            string updatestaffUrl = $"{staffUrl}api/Staff/CreateStaff";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(createStaffDto);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PostAsync(updatestaffUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }

            return NotFound();


        }

        // DELETE: api/Staff/5
        [HttpDelete("DeleteStaff/{id}")]
        public async Task<IActionResult> DeleteStaff(int id)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Assuming you have the base URL stored in staffUrl
            string updatestaffUrl = $"{staffUrl}api/Staff/DeleteStaff";

            // Serialize the Department object to JSON
            var jsonDepartment = JsonConvert.SerializeObject(id);
            var content = new StringContent(jsonDepartment, Encoding.UTF8, "application/json");

            // Send the HTTP PUT request
            HttpResponseMessage response = await _httpClient.PostAsync(updatestaffUrl, content);

            if (response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode);
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound();
            }
            else
            {
                // Handle other status codes as needed
                return StatusCode((int)response.StatusCode);
            }
        }
        [HttpPost("GetStaffByCredentials")]
        public async Task<ActionResult<StaffDto>> GetStaffByCredentials(UserModel user)
        {
            if (string.IsNullOrEmpty(user.EmailAddress) || string.IsNullOrEmpty(user.Password))
            {
                return BadRequest("EmailAddress and password are required.");
            }
            // Assuming you have the base URL stored in staffUrl
            string getStaffByCredentialsUrl = $"{staffUrl}api/Staff/GetStaffByCredentials?emailAddress="+user.EmailAddress+"&password="+user.Password; // Serialize the Department object to JSON
           
            HttpResponseMessage response = await _httpClient.GetAsync(getStaffByCredentialsUrl);

            if (response.IsSuccessStatusCode)
            {
                if (response.Content != null)
                {
                    var staff = await response.Content.ReadFromJsonAsync<StaffDto>();
                    return Ok(staff);
                }
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return NotFound("Staff not found.");
            }

            // Handle other status codes as needed
            return StatusCode((int)response.StatusCode);
        }



    }
}
