﻿using DepartmentService.Entities;
using Microsoft.EntityFrameworkCore;

namespace DepartmentService.DBContexts
{
    public class MyDBContext : DbContext
    {

        public DbSet<Department> Departments { get; set; }
        public MyDBContext(DbContextOptions<MyDBContext> options) : base(options)
        {

        }
    }
}
