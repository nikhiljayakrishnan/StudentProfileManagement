﻿using DepartmentService.Entities;

namespace DepartmentService.Dtos
{
    public class DepartmentDto : Department
    {
        public List<StaffDto> Staffs { get; set; }
        public List<StudentDto> Students { get; set; }

    }
}
