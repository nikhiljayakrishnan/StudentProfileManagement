﻿

using System.ComponentModel.DataAnnotations;

namespace DepartmentService.Dtos
{
    public class StaffDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public TypeEnum Type { get; set; }
        public int? DepartmentId { get; set; }
    }
    public enum TypeEnum
    {
        Teacher = 1,
        [Display(Name = "NonTeaching Staff")]
        NonTeachingStaff = 2
    }
}
