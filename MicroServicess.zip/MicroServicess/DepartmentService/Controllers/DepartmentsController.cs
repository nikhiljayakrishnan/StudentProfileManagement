﻿using DepartmentService.DBContexts;
using DepartmentService.Dtos;
using DepartmentService.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DepartmentService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentsController : ControllerBase
    {
        private readonly MyDBContext _context;
        //private readonly HttpClient _httpClient;
        public DepartmentsController(MyDBContext context)
        {
            _context = context;
          //  _httpClient = httpClient;
        }
        //private async Task<List<StaffDto>> GetStaffsByDepartmentId(int departmentId,string url= "http://localhost:21750/")
        //{
        //    HttpResponseMessage response = await _httpClient.GetAsync(url+"api/Staff/GetStaffsByDepartmentId/" + departmentId); // Adjust URL as needed
        //    List<StaffDto> staffs = new List<StaffDto>();
        //    if (response.IsSuccessStatusCode)
        //    {
        //        if (response.Content != null)
        //            staffs = await response.Content.ReadFromJsonAsync<List<StaffDto>>();

        //    }
        //    return staffs;

        //}
        //private async Task<List<StudentDto>> GetStudentsByDepartmentId(int departmentId,string url= "http://localhost:39384/")
        //{
        //    HttpResponseMessage response = await _httpClient.GetAsync(url+"api/Student/GetStudentsByDepartmentId/" + departmentId); // Adjust URL as needed
        //    List<StudentDto> students = new List<StudentDto>();
        //    if (response.IsSuccessStatusCode)
        //    {
        //        if (response.Content != null)
        //        {
        //            students = await response.Content.ReadFromJsonAsync<List<StudentDto>>();

        //        }

        //    }
        //    return students;

        //}
        // GET: api/Departments
        [HttpGet("GetDepartments")]
        public async Task<ActionResult<IEnumerable<Department>>> GetDepartments()
        {
            if (_context.Departments == null)
            {
                return NotFound();
            }
            var departments = await _context.Departments.ToListAsync();
            var data = departments.Select( s => new Department()
            {
                Id = s.Id,
                Name = s.Name,
                Subject = s.Subject,
               

            }).ToList();
            return Ok(data);
        }

        // GET: api/Departments/5
        [HttpGet("GetDepartment/{id}")]
        public async Task<ActionResult<Department>> GetDepartment(int id)
        {
            if (_context.Departments == null)
            {
                return NotFound();
            }
            var department = await _context.Departments.FindAsync(id);

            if (department == null)
            {
                return NotFound();
            }

            return department;
        }

        // PUT: api/Departments/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("UpdateDepartment")]
        public async Task<IActionResult> UpdateDepartment( Department department)
        {
            
            if (department.Id == 0)
            {
                return BadRequest();
            }
            var departmentEntity = await _context.Departments.FindAsync(department.Id);

            if (department.Name != "string")
            {
              departmentEntity.Name = department.Name ;
            }
            if (department.Subject != "string")
            {
                departmentEntity.Subject= department.Subject ;

            }
            _context.Departments.Update(departmentEntity);
           
            try
            {
                await _context.SaveChangesAsync();
                return Ok();

            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepartmentExists(department.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();

        }

        // POST: api/Departments
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("CreateDepartment")]
        public async Task<ActionResult<Department>> Create([FromBody] CreateOrUpdateDepartmentDto createOrUpdateDepartmentDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var department = new Department()
            {
                Name = createOrUpdateDepartmentDto.Name,
                Subject = createOrUpdateDepartmentDto.Subject
            };
            await _context.Departments.AddAsync(department);
            await _context.SaveChangesAsync();

            return Ok(department);
        }

        // DELETE: api/Departments/5
        [HttpDelete("DeleteDepartment/{id}")]
        public async Task<IActionResult> DeleteDepartment(int id)
        {
            if (_context.Departments == null)
            {
                return NotFound();
            }
            var department = await _context.Departments.FindAsync(id);
            if (department == null)
            {
                return NotFound();
            }

            _context.Departments.Remove(department);
            await _context.SaveChangesAsync();

            return Ok();
        }
        private bool DepartmentExists(int id)
        {
            return (_context.Departments?.Any(e => e.Id == id)).GetValueOrDefault();
        }

    }
}
