﻿
using Microsoft.EntityFrameworkCore;
using StaffService.Entities;

namespace StaffService.DBContexts
{
    public class MyDBContext : DbContext
    {

        public DbSet<Staff> Staffs { get; set; }
        public MyDBContext(DbContextOptions<MyDBContext> options) : base(options)
        {

        }
    }
}
