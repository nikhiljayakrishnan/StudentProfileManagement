﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StaffService.DBContexts;
using StaffService.Dtos;
using StaffService.Entities;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Security.Claims;
using System.Text;

namespace StaffService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly MyDBContext _context;

        public StaffController(MyDBContext context)
        {
            _context = context;
        }
        // GET: api/Staffs
        [HttpGet("GetStaffs")]
        public async Task<ActionResult<IEnumerable<StaffDto>>> GetStaffs()
        {
            if (_context.Staffs == null)
            {
                return NotFound();
            }
            var staffs = await _context.Staffs.ToListAsync();
            var data = staffs.Select(async s => new StaffDto()
            {
                Id = s.Id,
                Name = s.Name,
                DepartmentId = s.DepartmentId,
                Category = EnumHelper.GetDisplayName(s.Type)

            }).ToList();
            return Ok(data);
            ///needs to show the Staff and students count
        }
        public static class EnumHelper
        {
            public static string GetDisplayName(Enum value)
            {
                var field = value.GetType().GetField(value.ToString());
                var attribute = (DisplayAttribute)Attribute.GetCustomAttribute(field, typeof(DisplayAttribute));
                return attribute == null ? value.ToString() : attribute.Name;
            }
        }

        [HttpGet("GetStaffsByDepartmentId/{departmentId}")]
        public async Task<List<Staff>> GetStaffsByDepartmentId(int departmentId)
        {
            if (_context.Staffs == null)
            {
                return new List<Staff>();
            }
            var staffs = await _context.Staffs.Where(s => s.DepartmentId == departmentId).ToListAsync();
            return staffs;
            ///needs to show the Staff and students count
        }
      
        //// GET: api/Staffs/5
        [HttpGet("GetStaff/{id}")]
        public async Task<ActionResult<Staff>> GetStaff(int id)
        {
            if (_context.Staffs == null)
            {
                return NotFound();
            }
            var Staff = await _context.Staffs.FindAsync(id);

            if (Staff == null)
            {
                return NotFound();
            }

            return Staff;
        }

        // PUT: api/Staffs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("UpdateStaff")]
        public async Task<IActionResult> UpdateStaff(StaffDto staff)
        {
            if (staff.Id == 0)
            {
                return BadRequest();
            }
            var staffEntity = await _context.Staffs.FindAsync(staff.Id);
            if (staff.Name != "string")
            {
                staffEntity.Name = staff.Name;
            }
            if (staff.Type != TypeEnum.None)
            {
                staffEntity.Type = staff.Type;
            }
            if (staff.DepartmentId != 0)
            {
                staffEntity.DepartmentId = staff.DepartmentId;
            }
            _context.Staffs.Update(staffEntity);

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StaffExists(staff.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Staffs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("CreateStaff")]
        public async Task<ActionResult<Staff>> Create([FromBody] CreateStaffDto staff)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var staffEntity = new Staff()
            {
                Name = staff.Name,
                DepartmentId = staff.DepartmentId,
                Type = staff.Type,
                EmailAddress =staff.EmailAddress,
                Password = staff.Password
            };
            await _context.Staffs.AddAsync(staffEntity);
            await _context.SaveChangesAsync();

            return Ok(staffEntity);
        }

        // DELETE: api/Staffs/5
        [HttpDelete("DeleteStaff/{id}")]
        public async Task<IActionResult> DeleteStaff(int id)
        {
            if (_context.Staffs == null)
            {
                return NotFound();
            }
            var staff = await _context.Staffs.FindAsync(id);
            if (staff == null)
            {
                return NotFound();
            }

            _context.Staffs.Remove(staff);
            await _context.SaveChangesAsync();

            return Ok();
        }
        [HttpGet("GetStaffByCredentials")]
        public async Task<ActionResult<Staff>> GetStaffByCredentials(string emailAddress, string password)
        {
            if (string.IsNullOrEmpty(emailAddress) || string.IsNullOrEmpty(password))
            {
                return BadRequest("EmailAddress and password are required.");
            }

            var staff = await _context.Staffs.FirstOrDefaultAsync(s => s.EmailAddress == emailAddress && s.Password == password);

            if (staff == null)
            {
                return NotFound("Staff not found.");
            }

            return staff;
        }


        private bool StaffExists(int id)
        {
            return (_context.Staffs?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

