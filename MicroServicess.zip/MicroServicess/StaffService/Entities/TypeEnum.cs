﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace StaffService.Entities
{
    public enum TypeEnum
    {
        [Display(Name = "None")]
        None = 0,
        [Display(Name = "Teacher")]
        Teacher = 1,
        [Display(Name = "NonTeaching Staff")]
        NonTeachingStaff = 2
    }
}
