﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StaffService.Entities
{
    public class Staff
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }
        public TypeEnum Type { get; set; }
        public int? DepartmentId { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }

    }
}
